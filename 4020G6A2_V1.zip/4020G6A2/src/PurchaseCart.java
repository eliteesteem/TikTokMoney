
public class PurchaseCart{
	int cId = 0;
	int pId = 0;
	String pname = "";
	float price=0 ;
	float amount=0;
	int uId = 0 ;
	int count = 0;
	String storelocation="";
	public int getcId() {
		return cId;
	}
	public void setcId(int cId) {
		this.cId = cId;
	}
	public int getpId() {
		return pId;
	}
	public void setpId(int pId) {
		this.pId = pId;
	}
	public String getPname() {
		return pname;
	}
	public void setPname(String pname) {
		this.pname = pname;
	}
	public float getPrice() {
		return price;
	}
	public void setPrice(float price) {
		this.price = price;
	}
	public float getAmount() {
		return amount;
	}
	public void setAmount(float amount) {
		this.amount = amount;
	}
	public int getuId() {
		return uId;
	}
	public void setuId(int uId) {
		this.uId = uId;
	}
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}
	public String getStorelocation() {
		return storelocation;
	}
	public void setStorelocation(String storelocation) {
		this.storelocation = storelocation;
	}
	
	
          
}
